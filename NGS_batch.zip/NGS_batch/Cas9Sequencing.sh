#! /bin/sh
#### parameter ####
## pattern: the Regular expression to search edit region
## pattern_indel: the Regular expression to search idel from unregonized reads
## length: character length which 'pattern' included
## Q: sequencing quanlity, if Q >= 0, which sequencing quanlity below the threshold will be replaced as 'N'

pattern=$1
pattern_indel=$2
length=$3
Q=$4
fastqdir=$5

cd ../$5

gunzip *

for seq in $(ls *fastq | sed 's/.fastq//g')
do
	echo $seq
	cp $seq.fastq ../NGS_batch/fastq
	cd ../NGS_batch/fastq
	#fastx_quality_stats -i $seq.fastq -o ../out/summary_$seq.txt -Q 33
    fastq_quality_converter -n -Q 33 -i ${seq}.fastq -o ../fq_trans/${seq}_trans.fastq
	python3 ../pattern_extract.py ../fq_trans/${seq}_trans.fastq ../fl_result/extract/${seq}.extract.txt ../fl_result/indel/${seq}_indel.txt $pattern $pattern_indel $Q > ../log/${seq}_log.txt
	python3 ../result_stat.py ../fl_result/extract/${seq}.extract.txt $length ../edit_site.txt ../fl_result/summary/${seq}_seqscan.txt ../fl_result/summary/${seq}_productsum.txt
	awk '{a[$1]++}END{for(i in a){print i, a[i] | "sort -r -n -k 2"}}' ../fl_result/extract/${seq}.extract.txt > ../fl_result/count/${seq}_count.txt
	cd ../../$5
done

