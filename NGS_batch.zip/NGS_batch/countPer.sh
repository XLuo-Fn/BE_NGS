#! /bin/sh
##run the basepercentage.py for all _seqscan.txt

cd ./fl_result/summary

for input1 in $(ls *R1_seqscan.txt)
do
    echo -e '*' '\t' $input1 >> ./SumPer.txt
    python3 ../../basepercentage.py ${input1} ./per_${input1} ./SumPer.txt
done

echo -e '-------------------------------------------' >> ./SumPer.txt

for input2 in $(ls *R2_seqscan.txt)
do
    echo -e '*' '\t' $input2 >> ./SumPer.txt
    python3 ../../basepercentage.py ${input2} ./per_${input2} ./SumPer.txt
done
