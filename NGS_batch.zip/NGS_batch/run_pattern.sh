#!/bin/bash

# 定义输入文件路径
INPUT_FILE="pattern.txt"
# 定义目标根目录
TARGET_ROOT="../result"

if [ ! -f "$INPUT_FILE" ]; then
    echo "错误：找不到指定的文件 '$INPUT_FILE'！"
    exit 1
fi

# 确保目标根目录存在，如果不存在则创建
mkdir -p "$TARGET_ROOT"

echo "开始读取 $INPUT_FILE 并执行任务..."

while IFS= read -r line || [ -n "$line" ]; do
    
    # 1. 清理 Windows 回车符 (\r)
    line=$(echo "$line" | tr -d '\r')

    # 2. 将 TAB 替换为空格，方便后续解析
    line=$(echo "$line" | tr '\t' ' ')

    # 跳过空行
    if [ -z "$line" ]; then
        continue
    fi

    # 3. 【核心修改】提取第 5 个参数作为文件夹名称
    # 使用 set 命令将 line 的内容解析为位置参数 $1, $2, $3, $4, $5
    set -- $line
    DIR_NAME=$5

    echo "------------------------------------"
    echo "正在执行: sh Cas9Sequencing.sh $line"
    echo "目标文件夹名: $DIR_NAME"
    
    # 运行原始逻辑
    sh Cas9Sequencing.sh $line
    sh countPer.sh

    # 4. 【核心修改】执行复制并重命名操作
    # 这里的 -r 表示递归复制整个目录，确保结果被存入 ../result/s37 这种格式
    if [ -n "$DIR_NAME" ]; then
        cp -r ./fl_result/ "$TARGET_ROOT/$DIR_NAME"
        echo "已将结果复制到: $TARGET_ROOT/$DIR_NAME"
    else
        echo "警告：未能获取到第 5 个参数，跳过复制步骤。"
    fi

    sh clean.sh
    
done < "$INPUT_FILE"

echo "------------------------------------"
echo "所有任务已执行完毕！"