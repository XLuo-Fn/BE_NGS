##count percentage of base' kinds in esch site
#30th May 2022
## Luoxi
## 794679195@qq.com

import sys

seqscan = open(sys.argv[1],'r')
out= open(sys.argv[2],'w')
out1 = open(sys.argv[3],'a')

#seqscan = open('XLD1_sample1_1_seqscan.txt')
#out = open('test','w')

for a in seqscan:
    b=[]
    a = a.strip().split('\t')
    #print(a[1])
    if a[0] == 'locus':
       # b = a.extend(a)
        out.write('\t'.join((a + a)) + '\n')
        out1.write('\t'.join((a)) + '\n')
    else:
        sum = int(a[1])+int(a[2])+int(a[3])+int(a[4])
        No = (a[0])
        perA = str(int(a[1])/sum)
        perT = str(int(a[2])/sum)
        perC = str(int(a[3])/sum)
        perG = str(int(a[4])/sum)
        perN = str(int(a[5])/sum)
        a.append(No)
        a.append(perA)
        a.append(perT)
        a.append(perC)
        a.append(perG)
        a.append(perN)
        b.append(No)
        b.append(perA)
        b.append(perT)
        b.append(perC)
        b.append(perG)
        b.append(perN)
        #a = a.strip().split()
        #print(a)
        #print(b)
        out.write('\t'.join(a) + '\n')
        out1.write('\t'.join(b) + '\n')


