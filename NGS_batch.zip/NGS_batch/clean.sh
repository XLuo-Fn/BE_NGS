#!/bin/bash

echo "===================================="
echo "准备清理测序数据过程文件..."

# 1. 安全校验：检查当前目录是否确实是 NGS_fastq 工作目录
if [ ! -d "fastq" ] || [ ! -d "fl_result" ] || [ ! -d "log" ]; then
    echo "⚠️ 严重警告：当前目录下未检测到 fastq、fl_result 或 log 等关键文件夹！"
    echo "请确认你是否在正确的 NGS_fastq 目录内运行此脚本。"
    echo "清理任务已中止。"
    exit 1
fi

# 2. 执行清理任务
echo "正在清空指定目录内的文件（保留文件夹结构）..."

# 使用 find 命令精准锁定并删除文件 (-type f)
find fastq fl_result/count fl_result/extract fl_result/indel fl_result/summary fq_trans log -type f -delete

echo "清理完成！你的工作目录现在非常干净。"
echo "===================================="