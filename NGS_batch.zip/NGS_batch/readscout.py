import os

# 定义输入目录和输出文件路径
input_dir = './fl_result/count/'
output_file = './output.txt'

# 创建一个空字典来存储结果
results = {}

# 遍历目录中的所有文件
for filename in os.listdir(input_dir):
    if filename.endswith('.R1_count.txt'):
        # 获取文件的前缀名
        prefix = filename.split('.')[0]
        
        # 读取R1文件并过滤不包含'N'的行
        file_path = os.path.join(input_dir, filename)
        with open(file_path, 'r') as f:
            # 读取所有行，去除空白并过滤掉包含'N'的行
            lines = [line.strip().split() for line in f.readlines() if 'N' not in line.strip()]

        # 只保留前6行
        results[prefix] = {'R1': lines[:6]}  # 存储R1数据

    elif filename.endswith('.R2_count.txt'):
        # 获取文件的前缀名
        prefix = filename.split('.')[0]
        
        # 读取R2文件并过滤不包含'N'的行
        file_path = os.path.join(input_dir, filename)
        with open(file_path, 'r') as f:
            # 读取所有行，去除空白并过滤掉包含'N'的行
            lines = [line.strip().split() for line in f.readlines() if 'N' not in line.strip()]
        
        # 将R2数据存储到字典中
        if prefix in results:
            results[prefix]['R2'] = lines[:6]  # 只保留前6行的R2数据

# 将结果写入输出文件
with open(output_file, 'w') as out_f:
    for prefix, data in results.items():
        # 提取R1和R2数据
        r1_lines = data.get('R1', [])
        r2_lines = data.get('R2', [])
        
        # 确保R1和R2都是6行
        for r1, r2 in zip(r1_lines, r2_lines):
            out_f.write(f"{prefix}\t" + "\t".join(r1) + "\t" + "\t".join(r2) + '\n')  # 以制表符分隔并写入文件

print("提取完成，结果已写入到", output_file)

